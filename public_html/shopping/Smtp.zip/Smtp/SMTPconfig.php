<?php
//Server Address
$SmtpServer="dreamuniforms.ae";
$SmtpPort="25";
$SmtpUser="website@dreamuniforms.ae";
$SmtpPass="Hello@1985";
?>
