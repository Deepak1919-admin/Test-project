<?php
//include('header_thk.php');
include('header_inner.php');
include("banner.php");
session_start();
ob_start();


$AllEmail=$objEmail->GetRowContent(1);

if($_REQUEST['response_message']=="Success") {
    if ($_REQUEST['merchant_reference']) {
        $orderid = $_REQUEST['merchant_reference'];
        echo $successmsg = "<p style='font-size:15px;color:red; border:1px solid #ccc;padding:10px;'>Thank You Purchasing</p>";
    }
    $chkqry=mysql_query("SELECT * FROM `tblorder` WHERE transactionid=".$_REQUEST['fort_id']);
	$numrow1=mysql_num_rows($chkqry); 
	if(!$numrow1>0)
	{
		$date = date("d/m/Y");
		$time = date("h:i:s");
		$transid=$_REQUEST['fort_id'];
		$st="paid";
		$upqry="Update `tblorder` set date='$date',time='$time',transactionid='$transid',status='$st' where order_id='$orderid'";
		mysql_query($upqry);
		$getodr=$objOrder->GetRowContentOid($_REQUEST['merchant_reference']);
		$uid=$getodr['userid'];
		$getuser=$objUser->GetRowContent($uid);
		$_SESSION['useremail']=$getuser['email'];
		$getorderDet=$objOrderDetails->SelectOrderDetails($getodr['id']);

		foreach($getorderDet as $ODetails)
		{
			$getStk=$ObjProductPrice->GetRowContent($ODetails['mainId']);
			$oldstk=$getStk['stock'];
			$newstk=$oldstk-$ODetails['quantity'];
			$sqlstk = "update product_price set stock=$newstk where id=".$ODetails['mainId'];
			$restk = mysql_query($sqlstk);
		}
		$getCntry=$objCounrty->GetRowContent($getuser['country']);
		$curl = curl_init();
		curl_setopt_array(
			$curl, array(
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_URL => 'http://parzel.com/vendor/T0215.php',
				CURLOPT_USERAGENT => 'PARZEL EXPRESS',
				CURLOPT_POST => 1,
				CURLOPT_FOLLOWLOCATION =>1,
				CURLOPT_POSTFIELDS => array(
					'orderid' => $_REQUEST['merchant_reference'],
					'consignee' => $getuser['fname'],
					'consigneecperson' => $getuser['lname'],
					'consigneeaddress1' => $getuser['address'],
					'consigneeaddress2' => $getuser['address'],
					'consigneephone' => $getuser['phone'],
					'consigneecity' => $getuser['city'],
					'consigneecountry' => $getCntry['name'],
					'price' => $_SESSION['total'],
					'weight' => '0',
					'quantity' => $_SESSION['quantity'],
					'paymentmethod' => 'CC',  
					'goodsdescription' => 'AS PER ORDER ID',
					'specialinstruction' => 'Delivery',
				)
			)
		);
		$response = curl_exec($curl);
		echo $response;
		curl_close($curl); 
		if(!curl_exec($curl)){
			die('Error:"' . curl_error($curl) . '" - Code ' . curl_errono($curl));
		} 
	}
}
elseif($_GET['paylater'])
{

    $orderid= $_GET['paylater'];
    echo $successmsg="<p style='font-size:15px;color:green;border-bottom:1px solid #ccc;padding: 20px;text-align: center;font-weight: 600;font-size: 20px;letter-spacing: 0.04em;'>Thank You For Placing Order With DreamUniform</p>";

}
else
{
if($_REQUEST['response_message']=="Transaction declined")
{
echo $errormsg="<p style='font-size:15px;color:red;border-bottom:1px solid #ccc;padding: 20px;text-align: center;font-weight: 600;font-size: 20px;letter-spacing: 0.04em;'>Your Transaction has been Rejected and Declined</p>";
}
else
{
echo $errormsg="<p style='font-size:15px;color:red;border-bottom:1px solid #ccc;padding: 20px;text-align: center;font-weight: 600;font-size: 20px;letter-spacing: 0.04em;'>".$_REQUEST['response_message']."</p>";

}
}


if($_REQUEST['response_message']=="Success" || $_GET['paylater'])
{

	$gettemp="SELECT * FROM `tblorder` WHERE order_id='".$orderid."'";
	$Getresulttemp=mysql_query($gettemp);
	$numrow=mysql_num_rows($Getresulttemp);
	if($numrow>0)
	{
		$rowtemp=mysql_fetch_array($Getresulttemp);
		if($_SESSION['dream']['type'] == 'user'){
			$Getuser=$objUsers->GetRowContent($rowtemp['userid']);
			$userName=$Getuser['first_name'];
		}
		if($_SESSION['dream']['type'] == 'school'){
			$Getuser=$objSchool->GetRowContent($rowtemp['userid']);
			$userName=$Getuser['name'];
			$mulemail=$Getuser['mul_email'];
		}
		else
		{
		    $mulemail="";
		}
		if($_SESSION['dream']['type'] == 'corporate'){
			$Getuser=$objCorporate->GetRowContent($rowtemp['userid']);
			$userName=$Getuser['name'];
		}
		$newname=$_SESSION['newname'];
		$GetOrderDet=$objOrderDetails->SelectOrder($rowtemp['id']);
	//------------------mail message----------------------------
		if($GetOrderDet) {
			$ms = "<div style='margin-left: 0px;margin-top: 0px;margin-right: 0px;margin-bottom: 0px;font-family:Arial, Helvetica, sans-serif;font-size:12px' id='printdiv'>
			<div style='width: 650px;margin:12px auto;padding: 15px;font-size: 14px;'>
			<table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>			
				<tbody>
				<tr>
				  <td style='vertical-align: top;border-bottom: 2px solid #444; padding: 0;'>
				    <table style='width: 100%; margin-bottom: 20px;'>
				      <tbody>
				      <tr>
				      <td style='vertical-align: top; line-height: 1.5em;  font-size: 15px;  letter-spacing: 0.02em;'>
				         Dream Uniforms LLC<br>
				  		Emirates Road,<br>
				  Dubai - 2265 5665 <br>
				  UAE.    
				  </td>					<td align='right'>
										<img src='http://a2itsolutions.com/dreamuniform/images/in-logo.png' width='260' height='83' class='CToWUd'>
									</td>
				      </tr>
				    </tbody>
				    </table>
				  </td>
 
				</tr>
				
				<tr>
				<td height='20' align='left' valign='top'>
							</td>
						</tr>
				
				
				<tr>
					<td height='250' align='left' valign='top'>
					<table width='100%' border='0' cellspacing='0' cellpadding='0'>
					<tbody>
					
					<tr>
							<td>
                              <table width='100%'>
                              <tbody>
                              <tr>
                                <td style='vertical-align: top;'>
                                " . $newname . "<br>
                               
                                </td>
                                <td align='right' style=' vertical-align: top;'>
  <div style=' width: 200px;  text-align: left;'>Invoice #<span style='float:right'>#542</span></div>
  
  <div style=' width: 200px; text-align: left; margin: 2px 0;'>invoice date <span style='float:right'>05/12/2016</span></div>
    
<div style=' width: 200px;  text-align:left;  background: #eee;  padding: 2px 10px; font-weight: 600;'>Amount Due <span style='float:right'>255 AED</span></div></td>
                                </tr>
                              </tbody>
                              </table>
  </td>
						</tr>	
						
						<tr>
							<td height='50' align='left' valign='top'>
							</td>
						</tr>
						
						<tr>
							<td align='left' valign='top'>
							<table width='100%' border='0' cellspacing='0' cellpadding='0'>
								<tr>
									<td width='25%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Item</strong></td>
									<td width='15%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Quantity</strong></td>
									<td width='15%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Price</strong></td>
									<td width='20%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Color</strong></td>
									<td width='10%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Size</strong></td>
									<td width='15%' bgcolor='#dddddd' style='color:#000000;padding: 8px 10px;'><strong>Total Price</strong></td>
								</tr>";
		foreach ($GetOrderDet as $products) {
			$GetSize=$objSize->GetRowContent($products['size']);
			$ms .= "<tr>
					   <td width='25%' style='border-bottom:1px solid #ccc; padding: 10px 10px;' height='25' " . $bg . " style='padding: 10px 10px;'>" . $products['pname'] . "</td>
					   <td width='15%' " . $bg . " style='padding: 10px 10px; border-bottom:1px solid #ccc'>" . $products['quantity'] . "</td>
					   <td width='15%' " . $bg . " style='padding: 10px 10px; border-bottom:1px solid #ccc'>" . $products['price'] . "</td>
					   <td width='20%' " . $bg . " style='padding: 10px 10px; border-bottom:1px solid #ccc'>" . $products['color'] . "</td>
					   <td width='10%' " . $bg . " style='padding: 10px 10px; border-bottom:1px solid #ccc'>" . $GetSize['title'] . "</td>
					   <td width='15%' " . $bg . " style='padding: 10px 10px; border-bottom:1px solid #ccc'>" . $products['price'] * $products['quantity'] . "</td>
					   </tr>";
		}
		$ms .= "</table></td></tr>
		<tr><td height='30' align='left' valign='top' style='border-bottom: 4px solid #ddd;'></td>
						</tr>
		<tr>
		<td>
		<table width='100%' style=' float: right;  margin-top: 10px;  max-width: 250px;'>
		<tr>					<td style='background-color:#FFFFFF;border-bottom:1px solid #ccc; padding:8px 0px;'  >Shipping Charge</td>
					<td style='background-color:#FFFFFF;border-bottom:1px solid #ccc; padding:8px 0px;' align='right'>" . $rowtemp['ship_charge'] . "</td>
				</tr>
				<tr>
					<td style='background-color:#FFFFFF;border-bottom:1px solid #ccc; padding:8px 0px;'><strong>Grand Total</strong></td>
					<td style='background-color:#FFFFFF;border-bottom:1px solid #ccc; padding:8px 0px;' align='right'  >" . $rowtemp['total'] . "</td>
				</tr>
				</table>
				</td>
				</tr>";
		$ms .= "<tr>
							<td height='120' align='left'>
								Regards,<br><strong style='color:#000;'>DreamUniform</strong>
								</td>
						</tr>
					</tbody>
				</table>
			</td>
			</tr>
			
			<tr>
				<td height='35' align='center' bgcolor='#F0f0f0'> <strong>T</strong> : +971 4 3340494  |  <strong>E</strong> - <a href='#' style='text-decoration:none;color:#000;!important;' target='_blank'>info@dreamuniform.com</a></td>
			</tr>
			<tr>
				<td height='40' align='center' bgcolor='#ddd' style='color:#000!important;'><strong>&copy; 2016 DreamUniform. All Rights Reserved.</strong></td>
			</tr>
		</tbody>
	</table>
	<div class='yj6qo'></div>
	<div class='adL'></div>
</div>
</div>
</div>
</div>
</div>";
		}
	}
	echo $ms;
	echo '<div style="text-align:center; margin-bottom:30px;"><button onclick="PrintDiv()">Print</button></div>';
}
//--------------------mail msg Ends-----------------------------------
if($_REQUEST['response_message']=="Success" || $_GET['paylater']) {
	if (!isset($_SESSION["visits"]))
        $_SESSION["visits"] = 0;
	
	//echo $_SESSION["visits"] = $_SESSION["visits"] + 1;
	//if ($_SESSION["visits"] == 1)
	//{
	//	$by="DreamUniform";
		$from=$_SESSION['dream']['email'];
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= "From: =?UTF-8?B?". base64_encode($by)."?= <".$from.">\r\n";
		$to=$AllEmail['to_email_address'];
		$subject ="Instant Payment Notification - Recieved Payment";
		mail($to, $subject, $ms, $headers);					
		$from1=$AllEmail['to_email_address'];			                          
		$headers1  = 'MIME-Version: 1.0' . "\r\n";
		$headers1 .= "Content-type: text/html; charset=utf-8\r\n";
		$headers1 .= "From: =?UTF-8?B?". base64_encode($by)."?= <".$from1.">\r\n";
		$headers1 .="Bcc:".$mulemail."\r\n" .
		$to1 = $_SESSION['dream']['email'];
		$subject1 = "DreamUniform Order Details";
		mail($to1 ,$subject1 ,$ms,$headers1);
	//}
}	
include('footer_thk.php');
$_SESSION['cart']="";
$_SESSION['total']="";
$_SESSION['shipcost']="";
unset($_SESSION['cart']);
unset($_SESSION['total']);
unset($_SESSION['shipcost']);
unset($_SESSION['quantity']);
unset($_SESSION['pname']);
unset($_SESSION['price']);
unset($_SESSION['image']);
unset($_SESSION['order_id']);
?>

<script type="text/javascript">
    function PrintDiv() {
        var divToPrint = document.getElementById('printdiv');
        var popupWin = window.open('', '_blank', 'width=900,height=700');
        popupWin.document.open();
        popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();
    }
</script>