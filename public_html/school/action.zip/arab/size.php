<?php
include("header_inner.php");
//$getArticle = $objArticle->GetRowContentByMenu($_GET['mmid']);
include("banner.php");
?>	
<div class="content">
		<div class="container">
			<div class="page-content">
			<h2 class="page-title">الأحجام المتوفرة</h2>
				<?php echo $school_dt['size_arab'];?>
			</div>
		</div>
	</div>
<?php include("footer_inner.php"); ?>