




/*
     FILE ARCHIVED ON 10:52:27 Dec 20, 2013 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:15:40 Mar 28, 2016.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
$(document).ready(function(){

	$("a#inline").fancybox({
			'hideOnContentClick': true,
			'width' : 840,
			'autoDimensions' : false
	});
	
});		