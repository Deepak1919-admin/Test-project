
<!DOCTYPE html>
<!-- saved from url=(0078)http://web.archive.org/web/20140418020737/http://dreamuniforms.ae/uniforms.php -->
<html lang="en-US" class="cufon-active cufon-ready"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<script type="text/javascript" async="" src="./home_files/ga.js"></script>
<script type="text/javascript" src="./home_files/analytics.js"></script>
<script type="text/javascript">archive_analytics.values.server_name="wwwb-app19.us.archive.org";archive_analytics.values.server_ms=296;</script>

<link type="text/css" rel="stylesheet" href="./home_files/banner-styles.css">
	
	<title> Dream Uniforms, Dubai,UAE. |  Customized Uniforms for Corporate, Retail Chain Stores, Schools, Hotels etc. </title>

	<meta name="description" content="Dream Uniforms LLC, Dubai is specialized in customized uniforms for various sectors including Corporate, Retail Chain Stores, Hospitality Industry, Hospitals, School, Airports  &amp; Air Lines.">

	<meta name="keywords" content="Dream Uniforms Dubai, customized uniforms dubai,  uniforms in all styles, Corporate Uniforms Dubai, Retail Chain Stores Uniforms Dubai, Hospitality Industry Uniforms Dubai, Hospitals Uniforms Dubai, School Uniforms Dubai.">
	
	<script type="text/javascript" src="./home_files/cufon-yui.js"></script>

  <style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}
  </style>
	
  <script type="text/javascript" src="./home_files/Myriad_Pro_400.font.js"></script>
	
	<link rel="stylesheet" href="./home_files/reset.css">
	<link rel="stylesheet" href="./home_files/960.css">
	<link rel="stylesheet" href="./home_files/text.css">
	<link rel="stylesheet" href="./home_files/basic.css">
			<script type="text/javascript">
				Cufon.replace('#intro');
				Cufon.replace('h4');
				Cufon.replace('#main-nav li a');				 		
			</script>
	
	
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-444492-25']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? '/web/20140418020737/https://ssl' : '/web/20140418020737/http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script></head>



<body style="background-image: url(./uniforms_files/gradient_bg.png);">




<!-- BEGIN WAYBACK TOOLBAR INSERT -->
<script type="text/javascript" src="./home_files/disclaim-element.js"></script>
<script type="text/javascript" src="./home_files/graph-calc.js"></script>
<script type="text/javascript">//<![CDATA[
var __wm = (function(imgWidth,imgHeight,yearImgWidth,monthImgWidth){
var wbPrefix = "/web/";
var wbCurrentUrl = "http://dreamuniforms.ae/uniforms.php";

var firstYear = 1996;
var displayDay = "18";
var displayMonth = "Apr";
var displayYear = "2014";
var prettyMonths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
var $D=document,$=function(n){return document.getElementById(n)};
var trackerVal,curYear = -1,curMonth = -1;
var yearTracker,monthTracker;
function showTrackers(val) {
  if (val===trackerVal) return;
  var $ipp=$("wm-ipp");
  var $y=$("displayYearEl"),$m=$("displayMonthEl"),$d=$("displayDayEl");
  if (val) {
    $ipp.className="hi";
  } else {
    $ipp.className="";
    $y.innerHTML=displayYear;$m.innerHTML=displayMonth;$d.innerHTML=displayDay;
  }
  yearTracker.style.display=val?"inline":"none";
  monthTracker.style.display=val?"inline":"none";
  trackerVal = val;
}
function trackMouseMove(event,element) {
  var eventX = getEventX(event);
  var elementX = getElementX(element);
  var xOff = Math.min(Math.max(0, eventX - elementX),imgWidth);
  var monthOff = xOff % yearImgWidth;

  var year = Math.floor(xOff / yearImgWidth);
  var monthOfYear = Math.min(11,Math.floor(monthOff / monthImgWidth));
  // 1 extra border pixel at the left edge of the year:
  var month = (year * 12) + monthOfYear;
  var day = monthOff % 2==1?15:1;
  var dateString = zeroPad(year + firstYear) + zeroPad(monthOfYear+1,2) +
    zeroPad(day,2) + "000000";

  $("displayYearEl").innerHTML=year+firstYear;
  $("displayMonthEl").innerHTML=prettyMonths[monthOfYear];
  // looks too jarring when it changes..
  //$("displayDayEl").innerHTML=zeroPad(day,2);
  var url = wbPrefix + dateString + '/' +  wbCurrentUrl;
  $("wm-graph-anchor").href=url;

  if(curYear != year) {
    var yrOff = year * yearImgWidth;
    yearTracker.style.left = yrOff + "px";
    curYear = year;
  }
  if(curMonth != month) {
    var mtOff = year + (month * monthImgWidth) + 1;
    monthTracker.style.left = mtOff + "px";
    curMonth = month;
  }
}
function hideToolbar() {
  $("wm-ipp").style.display="none";
}
function bootstrap() {
  var $spk=$("wm-ipp-sparkline");
  yearTracker=$D.createElement('div');
  yearTracker.className='yt';
  with(yearTracker.style){
    display='none';width=yearImgWidth+"px";height=imgHeight+"px";
  }
  monthTracker=$D.createElement('div');
  monthTracker.className='mt';
  with(monthTracker.style){
    display='none';width=monthImgWidth+"px";height=imgHeight+"px";
  }
  $spk.appendChild(yearTracker);
  $spk.appendChild(monthTracker);

  var $ipp=$("wm-ipp");
  $ipp&&disclaimElement($ipp);
}
return{st:showTrackers,mv:trackMouseMove,h:hideToolbar,bt:bootstrap};
})(525, 27, 25, 2);//]]>
</script>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  min-width:800px !important;
}
</style>

<script type="text/javascript">__wm.bt();</script>
<!-- END WAYBACK TOOLBAR INSERT -->


<div class="container_16">

	<div id="branding">
		<div class="grid_4">
			<a href="index.php"><img src="./home_files/dream_uniforms_logo.png" alt="dream_uniforms_logo" width="181" height="20"></a>
		</div>		
		<div class="grid_12">
			<ul id="main-nav">
				
        <li><a href="index.php" ><cufon class="cufon cufon-canvas" alt="Home" style="width: 40px; height: 15px;"><canvas width="51" height="17" style="width: 51px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Home</cufontext></cufon></a>
        </li>

				<li><a href="about_us.html"><cufon class="cufon cufon-canvas" alt="About " style="width: 48px; height: 15px;"><canvas width="64" height="17" style="width: 64px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>About </cufontext></cufon><cufon class="cufon cufon-canvas" alt="Us" style="width: 18px; height: 15px;"><canvas width="29" height="17" style="width: 29px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Us</cufontext></cufon></a>
        </li>
				
        <li><a href="uniforms.html" ><cufon class="cufon cufon-canvas" alt="Uniforms" style="width: 69px; height: 15px;"><canvas width="80" height="17" style="width: 80px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Uniforms</cufontext></cufon></a>
        </li>
				
        <li><a href="gallery.php" class="active" style="background: url(./home_files/active_menu_bg.png);"><cufon class="cufon cufon-canvas" alt="Gallery" style="width: 57px; height: 15px;"><canvas width="67" height="17" style="width: 67px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Gallery</cufontext></cufon></a>
        </li>
				
        <li><a href="clients.html"><cufon class="cufon cufon-canvas" alt="Clients" style="width: 52px; height: 15px;"><canvas width="63" height="17" style="width: 63px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Clients</cufontext></cufon></a>
        </li>
				<li><a href="contact.html"><cufon class="cufon cufon-canvas" alt="Contact" style="width: 61px; height: 15px;"><canvas width="72" height="17" style="width: 72px; height: 17px; top: -2px; left: -1px;"></canvas><cufontext>Contact</cufontext></cufon></a>
        </li>
			</ul>
		</div>
	</div>
	<div class="clear"></div>
	

	<div class="grid_6">
		<img src="./home_files/uniforms_main.jpg" alt="uniforms_main" align="center" width="650" height="899">
	</div>
	
		<div id="content-area">
		
		
		<div class="grid_5">
		
			<img src="./home_files/uniforms_gallery_link.png" alt="uniforms_shoes" width="280" height="137">	
			
</div>	

		<div class="grid_5">
		
			
			<a href="gallery.php">
				<img src="./home_files/uniforms_gallery_link.png" alt="uniforms_gallery_link">
			</a>
			
		</div>
		
</div>
	<div class="clear"></div>	
	<div id="footer">
		<div class="grid_16">
			© Copyright 2014 Dream Uniforms LLC, Dubai.  Web Design <a href="http://www.fivedimensions.co/" target="_blank">fivedimensions</a>
		</div>
	</div>
</div>






<!--
     FILE ARCHIVED ON 2:07:37 Apr 18, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:07:59 Mar 28, 2016.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->
</body></html>